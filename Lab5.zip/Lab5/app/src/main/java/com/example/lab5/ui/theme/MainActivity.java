public class MainActivity extends AppCompatActivity {

    private Button buttonFetchData;
    private TextView textViewData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonFetchData = findViewById(R.id.buttonFetchData);
        textViewData = findViewById(R.id.textViewData);

        buttonFetchData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fetchDataFromAPI();
            }
        });
    }

    private void fetchDataFromAPI() {
        ApiService service = RetrofitClient.getRetrofitInstance().create(ApiService.class);
        Call<API> call = service.obtenerDatos();
        call.enqueue(new Callback<API>() {
            @Override
            public void onResponse(Call<API> call, Response<API> response) {
                if (response.isSuccessful()) {
                    API api = response.body();
                    textViewData.setText("Fr: " + api.getDEF() + ", Fr: " + api.getDEF());
                } else {
                    textViewData.setText("Error al obtener datos");
                }
            }

            @Override
            public void onFailure(Call<API> call, Throwable t) {
                textViewData.setText("Fallo en la conexión: " + t.getMessage());
            }
        });
    }
}
