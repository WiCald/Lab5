public interface ApiService {
    @GET("endpoint_noc_cual")
    Call<RespuestaDelAPI> obtenerDatos();
}
